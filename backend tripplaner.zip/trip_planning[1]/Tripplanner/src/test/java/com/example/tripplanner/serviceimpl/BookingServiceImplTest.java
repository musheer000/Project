package com.example.tripplanner.serviceimpl;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class BookingServiceImplTest {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
