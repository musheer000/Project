import { Component, OnInit } from '@angular/core';
import { Trip } from '../../model/trip';
import { ActivatedRoute, Router } from '@angular/router';
import { TripserviceService } from '../../service/tripservice.service';

@Component({
  selector: 'app-updatetrip',
  standalone: false,
  templateUrl: './updatetrip.component.html',
  styleUrl: './updatetrip.component.css'
})
export class UpdatetripComponent implements OnInit{
  trip = new Trip();
  tripId:any;
  tripObject:any;
  constructor(
    private route: ActivatedRoute,
    private tripService: TripserviceService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.tripId = this.route.snapshot.paramMap.get('tripId');
      this.tripService.getTripById(this.tripId).subscribe(
        (Response:any)=>{
          this.trip=Response;
        }
      );
    }
    updateTrip(){
      this.tripService.updateTripById(this.tripId,this.trip).subscribe(
        (Response:any)=>{
          alert("trip is updated successfully!!")
          this.router.navigate(['managetrip'])
        }
      )

    }
  }
 
