import { Component, OnInit } from '@angular/core';
import { User } from '../../model/User';
import { Router } from '@angular/router';
import { UserDataService } from '../../service/user-data.service';

@Component({
  selector: 'app-viewuser',
  standalone: false,
  templateUrl: './viewuser.component.html',
  styleUrl: './viewuser.component.css'
})
export class ViewuserComponent implements OnInit{
  constructor(private route:Router,private userDataService:UserDataService,private router:Router){}
  user =new User();
  users:any;
  userId:any;
  selectedUser:boolean=false;
  ngOnInit(): void {
    this.userDataService.getAllUsers().subscribe(
      (response:any)=>{
        this.users=response;
      }
    )
  }
  viewUser(userId:any){
    this.userDataService.getUserById(userId).subscribe(
      (Response:any)=>{
        if(Response!=null)
        this.selectedUser=true;
        this.user=Response;
        this.userId=userId;
      }
    )

  }
  editUser(userId:any){
    this.router.navigate(['updateuser',userId])
  }
  deleteUser(userId:any){
    this.userDataService.deleteUser(userId).subscribe(
      (response:any)=>{
        this.users=response;
      }
    )
  }
}
