import { Trip } from "./trip";

export class Tourist{
    tId:number |null;
    tFirstName:string;
    tLastName:string;
    tEmail:string;
    tMobileNo:string;
    tAge:number;
    tGender:string;
    paymentId:string;
    trip?:Trip;
    constructor(){
        this.tId=null;
        this.tFirstName="";
        this.tLastName="";
        this.tEmail="";
        this.tMobileNo="";
        this.tAge=0;
        this.tGender="";
        this.paymentId="";
        
    }
}