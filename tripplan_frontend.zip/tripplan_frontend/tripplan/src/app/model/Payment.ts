export class Payment{
    paymentId:number|null;
    paymentMethod:string;
    paymentDateAndTime:string;
    totalAmount:number;
    status:string;
    
    constructor(){
        this.paymentId=null;
        this.paymentMethod="";
        this.totalAmount=0;
        this.paymentDateAndTime="";
        this.status="";
    }
}