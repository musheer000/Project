import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UserAuthService {

  url="http://localhost:8084/auth";
  constructor(private http:HttpClient) { }
  //login
  public isUserLoggedIn(){
    let user=sessionStorage.getItem('userId')
    return !(user==null)
  }
//logout
// logout(){
//   sessionStorage.removeItem('userId');
// }
//admin login api
// authenticate(mail:string,pass:string){
//   console.log(pass)
//   console.log(mail)
//   return this.http.get(`${this.url}/login/${mail}/${pass}`);
// }
// adminloginvalidation(email:string,userMobileNo:string,password:string)
//   {
//     if((userMobileNo.trim()==="9392150041"||email.trim()==="seethakahema4@gmail.com") && (password.trim()==="Manju@143")){
//       sessionStorage.setItem('authenticateUser',userMobileNo||email)
//       return true;
//     }
//     else
//     {
//       return false;
//     }
// }}
}