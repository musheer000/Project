import { TestBed } from '@angular/core/testing';

import { TransportationserviceService } from './transportationservice.service';

describe('TransportationserviceService', () => {
  let service: TransportationserviceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(TransportationserviceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
