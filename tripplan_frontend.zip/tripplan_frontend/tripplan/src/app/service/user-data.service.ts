import { HttpClient } from '@angular/common/http';
import { Injectable, OnInit } from '@angular/core';
import { User } from '../model/User';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class UserDataService implements OnInit {

  constructor(private http:HttpClient) { }
  url="http://localhost:8084/api/users"
ngOnInit(): void {
  
}
logout(){
  sessionStorage.removeItem('userId');
}
saveUser(user: User): Observable<User> {
  return this.http.post<User>(`${this.url}`, user);
}
getAllUsers(){
  return this.http.get(`${this.url}`);
}
getUserById(userId: number) {
  return this.http.get<User>(`${this.url}/id/${userId}`);
}
updateUserById(userId:any, user:any) {
  return this.http.put(`${this.url}/update/${userId}`, user);
}
deleteUser(userId: number) {
  return this.http.delete<void>(`${this.url}/delete/${userId}`);
  }
findUserByEmail(email:string){
  console.log(email);
  return this.http.get<User>(`${this.url}/email/${email}`);
}
findUserByMobileNo(userMobileNo:string){
  console.log(userMobileNo);
  return this.http.get<User>(`${this.url}/phone/${userMobileNo}`);
}
forgotpass(email:string){
  return this.http.get<User>(`${this.url}/forgotpass/${email}`);
}
updatenewpassbyemail(email:string,password:string,user:any){
  return this.http.put<User>(`${this.url}/update/${email}/${password}`,user);
}
updateUserByEmail(email:string,user:User){
  return this.http.put<User>(`${this.url}/updateUser/${email}`,user);
}
}
