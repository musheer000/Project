import { HttpClient } from '@angular/common/http';
import { Injectable, OnInit } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class BankserverService implements OnInit{


  url="http://localhost:8084/api/Bankserver"
  ngOnInit(): void {
    
  }
  constructor(private http:HttpClient) { }

  getCardDetailsbyCNumCVVD(cnum:any,cvv:any,edate:any){
    return this.http.get(`${this.url}/findcardnumcvv/${cnum}/${cvv}/${edate}`)
    
  }
  getUpi(upi:any){
        return this.http.get(`${this.url}/findbyupi/${upi}`)
  }


}
