import { Component, OnInit } from '@angular/core';
import { Wishlist } from '../../model/wishlist';
import { Router } from '@angular/router';
import { WishlistserviceService } from '../../service/wishlistservice.service';
import { LoginService } from '../../service/login.service';

@Component({
  selector: 'app-wishlist',
  standalone: false,
  templateUrl: './wishlist.component.html',
  styleUrl: './wishlist.component.css'
})
export class WishlistComponent implements OnInit {
  wishlist: Wishlist[] = [];  // Array to hold the wishlist items
  userId: number = 0;  // Placeholder for userId, set this to the logged-in user's ID
  hidebuy: boolean = false;

  constructor(
    private wishlistServiceService: WishlistserviceService,
    private router: Router,
    public loginService:LoginService
  ) {}

  ngOnInit(): void {
    if (this.loginService.isUserLoggedin()) {
      this.userId = Number(sessionStorage.getItem('userId'));  // Get userId from session storage
      this.getWishlist();  // Fetch the wishlist on component load
    } else {
      this.router.navigate(['/login']);  // Redirect to login if user is not logged in
    }
  }

  getWishlist(): void {
    this.wishlistServiceService.getWishlistsByUserId(this.userId).subscribe(
      (data) => {
        this.wishlist = data;  // Store the data in wishlist array
      },
      (error) => {
        console.error('Error fetching wishlist:', error);  // Handle errors
      }
    );
  }

  removeFromWishlist(id: number): void {
    this.wishlistServiceService.deleteWishlist(id).subscribe(
      () => {
        this.getWishlist();  // Refresh the wishlist after removal
      },
      (error) => {
        console.error('Error removing from wishlist:', error);  // Handle errors
      }
    );
  }

  bookTrip(tripId: number): void {
    this.router.navigate(['/book-trip', tripId]);  // Navigate to a booking page with tripId
  }
  back(): void {
    this.router.navigate(['../']);  // Go back to the previous page
  }
}

