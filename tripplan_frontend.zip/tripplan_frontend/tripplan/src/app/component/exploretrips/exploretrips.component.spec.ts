import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ExploretripsComponent } from './exploretrips.component';

describe('ExploretripsComponent', () => {
  let component: ExploretripsComponent;
  let fixture: ComponentFixture<ExploretripsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ExploretripsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ExploretripsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
