import { Component, OnInit } from '@angular/core';
import { User } from '../../model/User';
import { UserDataService } from '../../service/user-data.service';
import { Router } from '@angular/router';
import { Location } from '@angular/common';
@Component({
  selector: 'app-createaccount',
  standalone: false,
  templateUrl: './createaccount.component.html',
  styleUrls: ['./createaccount.component.css']
})
export class CreateaccountComponent implements OnInit {
  user = new User();
  cpass:any;
  disableSubmit: Boolean = true;
  password: any;
  isFirstNameValid: boolean = true;
  isLastNameValid: boolean = true;
  isEmailValid: boolean = true;
  isMobileValid: boolean = true;
  isPasswordValid: boolean = true;
  isAddressValid: boolean = true;
  isAgeValid: boolean = true;
  isGenderValid: boolean = true;

  ngOnInit(): void {}

  constructor(private location:Location,private userDataService: UserDataService, private router: Router) {}

  createAccount(password: string, email: string): void {
    this.userDataService.findUserByEmail(email).subscribe((Response) => {
      if (Response != null) {
        alert('This email ID or mobile number already exists.');
      } else {
        if (this.cpass === this.user.password) {
          this.userDataService.saveUser(this.user).subscribe(
            (Response: any) => {
              console.log(Response);
              alert('Account created successfully!');
              this.router.navigate(['login']);
            }
          );
        } else {
          alert('Password does not match Confirm Password.');
        }
      }
    });
  }
  goBack(): void {
    this.location.back(); // This will navigate to the previous page
  }
  firstnamevalid(event: any): void {
    this.user.firstName = event.target.value.trim();
    this.isFirstNameValid = /^[A-Za-z\s]{2,25}$/.test(this.user.firstName);
    this.checkValidation();
  }

  lastnamevalid(event: any): void {
    this.user.lastName = event.target.value.trim();
    this.isLastNameValid = /^[A-Za-z\s]{1,25}$/.test(this.user.lastName);
    this.checkValidation();
  }

  emailvalid(event: any): void {
    this.user.email = event.target.value.trim();
    this.isEmailValid= /^[a-zA-Z0-9._-]+@[a-zA-Z0-9-]+\.[a-zA-Z.]{2,4}$/.test(this.user.email);
    this.checkValidation();
  }

  userMobileNoValid(event: any): void {
    this.user.userMobileNo = event.target.value.trim();
    this.isMobileValid = /^[6-9][0-9]{9}$/.test(this.user.userMobileNo);
    this.checkValidation();
  }

  passwordValid(event: any): void {
    this.user.password = event.target.value.trim();
    this.isPasswordValid = /^[a-zA-Z0-9.-]+[@||&|%|*|$|-][a-zA-Z0-9-]{2,7}$/.test(this.user.password);
    this.checkValidation();
  }

  cPasswordValid(event: any): void {
    this.cpass = event.target.value.trim();
    this.isPasswordValid = this.cpass === this.user.password;
    this.checkValidation();
  }

  addressValid(event: any): void {
    this.user.address = event.target.value.trim();
    this.isAddressValid = /^[a-zA-Z0-9. ,-]{15,50}$/.test(this.user.address);
    this.checkValidation();
  }

  ageValid(event: any): void {
    this.user.userAge = event.target.value.trim();
    this.isAgeValid = this.user.userAge >= 18 && this.user.userAge <= 100;
    this.checkValidation();
  }

  genderValid(event: any): void {
    this.user.userGender = event.target.value;
    this.isGenderValid = !!this.user.userGender; // Ensuring a gender is selected
    this.checkValidation();
  }

  checkValidation(): void {
    this.disableSubmit =
      this.isFirstNameValid &&
      this.isLastNameValid &&
      this.isMobileValid &&
      this.isEmailValid &&
      this.isAddressValid &&
      this.isPasswordValid &&
      this.isAgeValid &&
      this.isGenderValid &&
      !!this.user.firstName &&
      !!this.user.lastName &&
      !!this.user.email &&
      !!this.user.userMobileNo &&
      !!this.user.address &&
      !!this.cpass &&
      !!this.user.userAge &&
      !!this.user.userGender
        ? false
        : true;
  }
}
